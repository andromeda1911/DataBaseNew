package com.example.nikhilsridhar.database;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Details extends AppCompatActivity {
    ImageView imageView;
    TextView tx_name, tx_pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_details_layout);

        imageView = (ImageView) findViewById(R.id.playerImage);
        tx_name   = (TextView) findViewById(R.id.nameTxt);
        tx_pos    = (TextView) findViewById(R.id.posTxt);
        imageView.setImageResource(getIntent().getIntExtra("img_id", 00));
        tx_name.setText("Name : "+ getIntent().getIntExtra("name", 00));
        tx_pos.setText("Position"+ getIntent().getIntExtra("pos", 00));


    }
}
